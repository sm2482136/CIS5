/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 24, 2018, 10:52 PM
 * Purpose: Project 1, Connect 4
 */

// Included libraries
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>

// Used for main operations like cin, cout, etc.
using namespace std;

// Constant for total percentage available.
const float PERCENT = 100.0f;

// Main program.
int main()
{
	// File to take input from.
	// Used to get the number of wins for red/black and ties.
	ifstream inFile;
	int rWins = 0, bWins = 0, ties = 0;

	// Open the file connect4.txt for reading.
	inFile.open("connect4.txt", ios::in);

	// If the file cannot be opened, then we need to create one.
	if (!inFile)
	{
		// Open new file for writing.
		ofstream newFile;

		// Open file connect4.txt for writing.
		newFile.open("connect4.txt", ios::out);

		// Close the new file.
		newFile.close();
	}
	else
	{
		// Variable used to hold text inside of the text file.
		string text;

		// Read in wins for red, black, and ties.
		inFile >> text >> text >> rWins;
		inFile >> text >> text >> bWins;
		inFile >> text >> ties;

		// Close the file for reading.
		inFile.close();
	}

	// Response variable to play the game again.
	char resp;

	// Repeat loop to play the game.
	do
	{
		// Board slots (1-16) for a 4x4 board. Will be increased later.
		char slot1 = 32, slot2 = 32, slot3 = 32, slot4 = 32;
		char slot5 = 32, slot6 = 32, slot7 = 32, slot8 = 32;
		char slot9 = 32, slot10 = 32, slot11 = 32, slot12 = 32;
		char slot13 = 32, slot14 = 32, slot15 = 32, slot16 = 32;

		// Choice of column to add chip to the screen.
		int choice;

		// Loop 16 times to insert into the board.
		for (int turns = 0; turns < 16; turns++)
		{
			// Output the top layer of the board frame.
			cout << "+";
			for (int i = 0; i < 4; i++)
				cout << "-+";
			cout << endl;

			// Output the top layer of chips.
			cout << "|" << slot1 << "|" << slot2 << "|" << slot3 << "|" << slot4 << "|" << endl;

			// Output the 2nd layer of the board frame.
			cout << "+";
			for (int i = 0; i < 4; i++)
				cout << "-+";
			cout << endl;

			// Output the 2nd layer of chips.
			cout << "|" << slot5 << "|" << slot6 << "|" << slot7 << "|" << slot8 << "|" << endl;

			// Output the 3rd layer of the board frame.
			cout << "+";
			for (int i = 0; i < 4; i++)
				cout << "-+";
			cout << endl;

			// Output the 3rd layer of chips.
			cout << "|" << slot9 << "|" << slot10 << "|" << slot11 << "|" << slot12 << "|" << endl;

			// Output the 4th layer of the board frame.
			cout << "+";
			for (int i = 0; i < 4; i++)
				cout << "-+";
			cout << endl;

			// Output the last layer of chips.
			cout << "|" << slot13 << "|" << slot14 << "|" << slot15 << "|" << slot16 << "|" << endl;

			// Output the last layer of the board frame.
			cout << "+";
			for (int i = 0; i < 4; i++)
				cout << "-+";
			cout << endl;

			// Ask the user to insert a chip to one of the column.
			// Get input from the user and store into choice.
			cout << "Enter a column to add a chip to (1-4): ";
			cin >> choice;
			cout << endl;

			// If the choice of column is bad (not 1-4), then ask the
			// user to get a good input.
			while (choice < 1 || choice > 4)
			{
				// Reask the user to insert a chip into a valid column.
				// Get input from the user and store into choice.
				cout << "Error, bad column.  Re-enter a column to add a chip to (1-4): ";
				cin >> choice;
				cout << endl;
			}

			// Mark is the player's chip put into the board.
			// Player 1 is represented by 1, Player 2 is represented by 2.
			// If turn number is even, it is player 1, otherwise it is player 2.
			char mark = 'R';
			if (fmod(turns, 2.0f) == 1)
				mark = 'B';

			// Loop to put a chip into a valid location on the board.
			bool badCol = false;
			do
			{
				// If choice is invalid or full (-1), then ask the user
				// to reenter a new valid column.
				while (badCol || choice < 1 || choice > 4)
				{
					cout << "Error, full or bad column.  Re-enter a column to add a chip to (1-4): ";
					cin >> choice;
					cout << endl;
					badCol = false;
				}

				// Switch statement to put a chip into the right location. 
				switch (choice)
				{
					// If column 1.
					case 1: if (slot13 == 32) // If bottom row is empty, put here.
								slot13 = mark;
							else if (slot9 == 32) // Else if 2nd bottom row is empty, put here.
								slot9 = mark;
							else if (slot5 == 32) // Else if 3rd bottom row is empty, put here.
								slot5 = mark;
							else if (slot1 == 32) // Else if top row is empty, put here.
								slot1 = mark;
							else
								badCol = true; // Otherwise it's a bad column.
							break;
					// If column 2.
					case 2: if (slot14 == 32) // If bottom row is empty, put here.
								slot14 = mark;
							else if (slot10 == 32) // Else if 2nd bottom row is empty, put here.
								slot10 = mark;
							else if (slot6 == 32) // Else if 3rd bottom row is empty, put here.
								slot6 = mark;
							else if (slot2 == 32) // Else if top row is empty, put here.
								slot2 = mark;
							else
								badCol = true; // Otherwise it's a bad column.
							break;
					// If column 3.
					case 3: if (slot15 == 32) // If bottom row is empty, put here.
								slot15 = mark;
							else if (slot11 == 32) // Else if 2nd bottom row is empty, put here.
								slot11 = mark;
							else if (slot7 == 32) // Else if 3rd bottom row is empty, put here.
								slot7 = mark;
							else if (slot3 == 32) // Else if top row is empty, put here.
								slot3 = mark;
							else
								badCol = true; // Otherwise it's a bad column.
							break;
					// If column 4.
					case 4: if (slot16 != 32) { // If bottom row is empty, put here.
								if (slot12 != 32) { // Else if 2nd bottom row is empty, put here.
									if (slot8 != 32) { // Else if 3rd bottom row is empty, put here.
										if (slot4 == 32) // Else if top row is empty, put here.
											slot4 = mark;
										else
											badCol = true; // Otherwise it's a bad column.
									}
									else 
										slot8 = mark;
								}
								else
									slot12 = mark;
							}
							else 
								slot16 = mark;
							break;
				}
			// If choice became -1 because the column was full, loop again.
			} while (badCol || choice < 1 || choice > 4);
		}

		// Output the top layer of the board frame.
		string frame = "+-+-+-+-+";
		cout << endl << setw(26) << frame << endl;

		// Output the top layer of chips.
		cout << setw(18) << "|" << slot1 << "|" << slot2 << "|" << slot3 << "|" << slot4 << "|" << endl;

		// Output the 2nd layer of the board frame.
		cout << setw(26) << frame << endl;

		// Output the 2nd layer of chips.
		cout << setw(18) << "|" << slot5 << "|" << slot6 << "|" << slot7 << "|" << slot8 << "|" << endl;

		// Output the 3rd layer of the board frame.
		cout << setw(26) << frame << endl;

		// Output the 3rd layer of chips.
		cout << setw(18) << "|" << slot9 << "|" << slot10 << "|" << slot11 << "|" << slot12 << "|" << endl;

		// Output the 4th layer of the board frame.
		cout << setw(26) << frame << endl;

		// Output the last layer of chips.
		cout << setw(18) << "|" << slot13 << "|" << slot14 << "|" << slot15 << "|" << slot16 << "|" << endl;

		// Output the last layer of the board frame.
		cout << setw(26) << frame << endl << endl;

		// Ask the user if they want to play again.
		// Get response from user and put into response variable.
		cout << "Do you want to play again (y or n)?: ";
		cin >> resp;
		cout << endl;
	// Check if response is 'y' or 'Y'.  If so then play the entire game again.
	// Otherwise, end the game.
	} while (resp == 'y' || resp == 'Y');

	// Output information about the red wins, black wins, and ties.
	cout << "Red Wins: " << rWins << endl;
	cout << "Black Wins: " << bWins << endl;
	cout << "Ties: " << ties << endl << endl;

	// Calculate the number of games played. (Updated in Project 2).
	int games = rWins + bWins + ties;

	// Calculate the percentage for red and black wins.
	// If games is non-zero then calculate percentage.
	// Otherwise percentage is 0%.
	float redPerc = (games == 0 ? 0.0f : static_cast<float>(rWins) * PERCENT / games);
	float blkPerc = (games == 0 ? 0.0f : static_cast<float>(bWins) * PERCENT / games);

	// Print out the percentage for red/black wins.
	cout << "Red Win Percentage: " << fixed << showpoint << setprecision(2) << redPerc << "%" << endl;
	cout << "Black Win Percentage: " << fixed << showpoint << setprecision(2) << blkPerc << "%" << endl << endl;

	// Output stream for the data for the wins file.
	ofstream outFile;

	// Open the connect4.txt file for writing.
	outFile.open("connect4.txt", ios::out);

	// Output the red wins, black wins, and ties to the file.
	outFile << "Red Wins: " << rWins << endl;
	outFile << "Black Wins: " << bWins << endl;
	outFile << "Ties: " << ties << endl;

	// Close the output file.
	outFile.close();

	// End the program.
	return 0;
}
