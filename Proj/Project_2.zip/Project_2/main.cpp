/* 
 * File:   main.cpp (5)
 * Author: Shanilka Mapatuna
 * Created on February 7, 2018, 12:00 AM
 * Purpose: Project 2, Connect 4
 */

// Included libraries
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>

// Used for main operations like cin, cout, etc.
using namespace std;

// Function Prototypes
void drawBoard(char board[][7]);
int determineWinner(char board[][7], int row, int col, int turns);
void printHighestScorer(int scores[], string players[], int &size);
void printSortedScores(int scores[], string players[], int size = 0);
void outputToFile(int scores[], string players[], int wins, int lose, int ties, int size);
bool outOfBounds(int col);
bool outOfBounds(int row, int col);
vector<int> toVector(int arr[], int size);
vector<string> toVector(string arr[], int size);
void bubbleSort(vector<int> &scores, vector<string> &players);
int getNoCharInput();

int main()
{
	// File to take input from.
	// Used to get the number of wins for red/black and ties.
	ifstream inFile;
	int rWins = 0, bWins = 0, ties = 0;
	static int size = 0;
	
	// Player and score information.
	int score[50];
	string players[50];

	// Clear every value in score and player parallel arrays.
	for (int i = 0; i < 50; i++)
	{
		players[i] = "";
		score[i] = -1;
	}

	// Open the file connect4.txt for reading.
	inFile.open("connect4.txt", ios::in);

	// If the file cannot be opened, then we need to create one.
	if (!inFile)
	{
		// Open new file connect4.txt for writing.
		ofstream newFile;
		newFile.open("connect4.txt", ios::out);

		// Close the new file.
		newFile.close();

		// Exit.
		exit(0);
	}
	else
	{
		// Variable used to hold text inside of the text file.
		// Variable to hold score.
		string text;
		int sc;

		// Read in wins for red, black, and ties.
		inFile >> text >> text >> rWins >> text >> text >> bWins >> text >> ties;

		// Read in each record of (player, score)
		// Continue as long as there are people to read.
		while (inFile >> text >> sc)
		{
			players[size] = text;
			score[size] = sc;
			size++;
		}

		// Close the file for reading.
		inFile.close();
	}

	// Response variable to play the game again.
	char resp;

	// Repeat loop to play the game.
	do
	{
		// 42 Board slots for a 6x7 board.
		char board[6][7];

		// Go through each of the 42 locations and set them to blank.
		for (int i = 0; i < 6; i++)
			for (int j = 0; j < 7; j++)
				board[i][j] = 32;

		// Choice of column to add chip to the screen.
		// Does the board have a winner?
		int choice = 0, row;
		int player = -1, turns;

		// Loop 42 times to insert into the board.
		for (turns = 0; turns < 42 && player == -1; turns++)
		{
			// Draw the board on the screen.
			drawBoard(board);

			// Ask the user to insert a chip to one of the column.
			// Get input from the user and store into choice.
			cout << "Enter a column to add a chip to (1-7): ";
			choice = getNoCharInput();
			cout << endl;

			// If the choice of column is bad (not 1-4), then ask the
			// user to get a good input.
			while (outOfBounds(choice))
			{
				// Reask the user to insert a chip into a valid column.
				// Get input from the user and store into choice.
				cout << "Error, bad column.  Re-enter a column to add a chip to (1-7): ";
				choice = getNoCharInput();
				cout << endl;
			}

			// Mark is the player's chip put into the board.
			// Player 1 is represented by 1, Player 2 is represented by 2.
			// If turn number is even, it is player 1, otherwise it is player 2.
			char mark = 'R';
			if (fmod(turns, 2.0f) == 1)
				mark = 'B';

			// Loop to put a chip into a valid location on the board.
			bool badCol = false;
			do
			{
				// If choice is invalid or full (-1), then ask the user
				// to reenter a new valid column.
				while (badCol || outOfBounds(choice))
				{
					cout << "Error, full or bad column.  Re-enter a column to add a chip to (1-7): ";
					choice = getNoCharInput();
					cout << endl;
					badCol = false;
				}

				// Use this while loop to figure out where in the column to put it.
				row = 5;
				while (board[row][choice - 1] != 32 && row >= 0)
					row--;

				// Check this if statement to see if the chip can be placed in that
				// column OR we mark as a badCol.
				if (row >= 0)
					board[row][choice - 1] = mark;
				else if (row < 0)
					badCol = true;
				
			// If choice became -1 because the column was full, loop again.
			} while (badCol || outOfBounds(choice));

			// Determine the winner of the game, at this point.
			player = determineWinner(board, row, choice - 1, turns);
		}
		
		// Draw the board on the screen.
		drawBoard(board);

		// Determine who won the game.
		// Used to display the winner.
		switch (player)
		{
			// Player 1 wins.
			case 1: cout << "Player 1 (Chip R) Wins!" << endl;
				rWins++;
				break;
			// Player 2 wins.
			case 2: cout << "Player 2 (Chip B) Wins!" << endl;
				bWins++;
				break;
			// Neither player wins.
			default: cout << "Tie. No player wins." << endl;
				ties++;
				break;
		}

		// As long as it can be put into the array.
		if (size < 50)
		{
			// Ask the user for the name of the score.
			cout << "You have a score of " << 42 - turns << " points." << endl;
			cout << "Enter your name for this score: ";

			// Get the name of the scorer.
			string name;
			cin >> name;
			cout << endl;

			// Put the score and player's name into the array.
			players[size] = name;
			score[size] = 42 - turns;
			size++;
		}

		// Ask the user if they want to play again.
		// Get response from user and put into response variable.
		cout << "Do you want to play again (y or n)?: ";
		cin >> resp;
		cout << endl;
	// Check if response is 'y' or 'Y'.  If so then play the entire game again.
	// Otherwise, end the game.
	} while (resp == 'y' || resp == 'Y');

	// Calculate the percentage for red and black wins.
	// If games is non-zero then calculate percentage, otherwise 0%.
	int games = rWins + bWins + ties;
	float redPerc = (games == 0 ? 0.0f : static_cast<float>(rWins) * 100.0f / games);
	float blkPerc = (games == 0 ? 0.0f : static_cast<float>(bWins) * 100.0f / games);

	// Print out red wins, black wins, ties, and % for red/black wins.
	cout << "Red Wins: " << rWins << endl;
	cout << "Black Wins: " << bWins << endl;
	cout << "Ties: " << ties << endl;
	cout << "Red Win Percentage: " << fixed << showpoint << setprecision(2) << redPerc << "%" << endl;
	cout << "Black Win Percentage: " << fixed << showpoint << setprecision(2) << blkPerc << "%" << endl << endl;

	// Information about the location of the highest scorer and 
	printHighestScorer(score, players, size);

	// Print out the top 10 scores.
	printSortedScores(score, players, size);

	// Print to output file.
	outputToFile(score, players, rWins, bWins, ties, size);

	// End the program.
	return 0;
}

// Draws the entire board onto the screen.
void drawBoard(char board[][7])
{
	// Draws the board.
	for (int i = 0; i < 6; i++)
	{
		// Draw the frame part first.
		cout << "+";
		for (int j = 0; j < 7; j++)
			cout << "-+";
		cout << endl;

		// Draw the items inside of the frame.
		cout << "|";
		for (int j = 0; j < 7; j++)
			cout << board[i][j] << "|";
		cout << endl;
	}

	// Draw the bottom most frame part last.
	cout << "+";
	for (int j = 0; j < 7; j++)
		cout << "-+";
	cout << endl << endl;
}

// Determines the winner of the board at this time.
int determineWinner(char board[][7], int row, int col, int turns)
{
	// Direction to add (x,y) in the board to see if there is 4 in a row.
	int xAdd[] = { 0, 1, 1, 1, 0, -1, -1, -1 };
	int yAdd[] = { 1, 1, 0, -1, -1, -1, 0, 1 };

	// Go through all 8 directions.
	for (int i = 0; i < 8; i++)
	{
		// Does the board have a winner? 
		bool valid = true;

		// Go through 4 chips in a row.
		for (int inARow = 0; inARow < 4 && valid; inARow++)
		{
			// Calculate new (row, col) called (j, k) to check if there are 4 in a row.
			int j = row + (inARow * xAdd[i]);
			int k = col + (inARow * yAdd[i]);

			// Is (j, k) a valid location in the board?
			// If it is not valid, then valid = false.
			if (!outOfBounds(j, k))
			{
				// If the center point does not matches the 4 chips in a row
				// Then the direction is not valid.
				if (board[row][col] != board[j][k])
					valid = false;

				// Else it's okay at this point.
			}
			else
				valid = false;
		}

		// If it is valid, then a winner can be chosen.
		if (valid)
			return (static_cast<int>(fmod(turns, 2.0f)) + 1);
	}
	return -1;
}

// Prints the highest scorer so far for this game.
void printHighestScorer(int scores[], string players[], int &size)
{
	// Information about the location of the highest scorer and 
	int i, highS = -1;

	// Go through all scores of the array.
	for (size = 0; size < 50 && scores[size] != -1; size++)
	{
		// If a score is better, remember this as top score.
		if (scores[size] > highS)
		{
			highS = scores[size];
			i = size;
		}
	}

	// Print out best score and player.
	cout << "Highest Score: " << scores[i] << endl;
	cout << "Best Player: " << players[i] << endl << endl;
}

// Print the top 10 scorers from highest to lowest using Selection Sort
void printSortedScores(int scores[], string players[], int size)
{
	// Top 10 scores.
	cout << "Top 10 Players: " << endl;

	// Go through all people and sort them by score (descendingly).
	// Uses Selection Sort.
	for (int i = 0; i < size; i++)
	{
		// Get highest score and player.
		int p = i, highS = scores[i];

		// Go through items i+1 ... n
		for (int j = i + 1; j < size; j++)
		{
			// If score is better than current highS,
			// then change it to be the highest scorer.
			if (highS < scores[j])
			{
				highS = scores[j];
				p = j;
			}
		}

		// Swap scores.
		int tempS = scores[i];
		scores[i] = scores[p];
		scores[p] = tempS;

		// Swap players.
		string tempP = players[i];
		players[i] = players[p];
		players[p] = tempP;
	}

	// Print to the screen player, score information.
	for (int i = 0; i < 10 && i < size; i++)
		cout << (i + 1) << " - " << left << setw(15) << players[i] << " " << scores[i] << endl;
}

// Print all of the required information (wins, loses, ties, and high scorers) to file.
void outputToFile(int scores[], string players[], int wins, int lose, int ties, int size)
{
	// Output stream for the data for the wins file.
	// Open the connect4.txt file for writing.
	ofstream outFile;
	outFile.open("connect4.txt", ios::out);

	// Output the red wins, black wins, and ties to the file.
	// Print highest scores that are found.
	outFile << "Red Wins: " << wins << endl;
	outFile << "Black Wins: " << lose << endl;
	outFile << "Ties: " << ties << endl << endl;

	vector<int> sc = toVector(scores, size);
	vector<string> pl = toVector(players, size);
	bubbleSort(sc, pl);

	for (int i = 0; i < 10 && i < size; i++)
		outFile << pl[i] << " " << sc[i] << endl;

	// Close the output file.
	outFile.close();
}

// Determines if the choice of column is bad.
// Returns true if it is, otherwise false.
bool outOfBounds(int col)
{
	return (col < 1 || col > 7);
}

// Determines if the choice of (row, column) is bad.
// Returns true if it is, otherwise false.
bool outOfBounds(int row, int col)
{
	return (row < 0 || row > 6 || col < 0 || col > 7);
}

// Convert array to vector.
vector<int> toVector(int arr[], int size)
{
	vector<int> vec;
	for (int i = 0; i < size; i++)
		vec.push_back(arr[i]);
	return vec;
}

// Convert array to vector.
vector<string> toVector(string arr[], int size)
{
	vector<string> vec;
	for (int i = 0; i < size; i++)
		vec.push_back(arr[i]);
	return vec;
}

// Sort two parallel vectors using Bubble Sort.
void bubbleSort(vector<int> &scores, vector<string> &players)
{
	// Was there a swap.
	bool swapped;
	do
	{
		// Set to false to start.
		swapped = false; 

		// Go through all scores.
		for (int i = 1; i < scores.size(); i++)
		{
			// If even one is out of a place.
			// Swap the i and i-1 positions and set swapped to true.
			if (scores.at(i - 1) > scores.at(i))
			{
				int tempS = scores[i - 1];
				scores[i - 1] = scores[i];
				scores[i] = tempS;

				string tempP = players[i - 1];
				players[i - 1] = players[i];
				players[i] = tempP;

				swapped = true;
			}
		}
	} while (swapped);
	// If no swap occurred, then we're done.
}

// Fix any input that is non-integer columns.
int getNoCharInput()
{
	int input;

	// Check if input is invalid
	while (!(cin >> input))
	{
		// Remove all junk characters
		cin.clear();
		cin.ignore(999, '\n');

		// Ask the user for good input.
		cout << endl << "Not an integer input, please try again (1-7): ";
	}

	// Return the good input.
	return input;
}