/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 10:00 PM
 * Assigment 1, Question 16
 */

// Personal Information  
#include <iostream>
using namespace std;

int main() 
{
    cout << "Shanilka Jehan Mapatuna\n"
         <<"15776 Bluechip cir. Moreno Valley, CA 92551\n"
         <<"951-956-6185\n"
         <<"Physics\n";

    return 0;
}

