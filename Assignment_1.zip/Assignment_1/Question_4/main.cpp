/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 8:49 PM
 * Assigment 1, Question 2
 */

// Ttoal Amount of Meal 
#include <iostream>
using namespace std;

int main() 
{
    float Meal, Tax, Tip, Taxamount, Tipamount, Total;
    
    Meal = 88.67; // In dollars 
    Tax = 0.0675; // Percentage Value 
    Tip = 0.020; // Percentage Value 
    Taxamount = Meal * Tax;
    Tipamount = Meal * Tip;
    Total = Taxamount + Tipamount + Meal;
    
    cout << "Total amount of the meal after tip and taxes is $ " << Total << endl;
    
     return 0;
}

