/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 8:19 PM
 * Assigment 1, Question 2
 */

// East Coast Earnings a year 
#include <iostream>
using namespace std;

int main() 
{
    float ECoastSales, TotalSales, ECoastEarnings ;
    
    ECoastSales = 0.58 ; //Percentage Value
    TotalSales = 8.6E6 ;
    ECoastEarnings = ECoastSales * TotalSales ;
            
    cout<<"East coast Division will generate the company " << ECoastEarnings << endl;
    return 0;
}

