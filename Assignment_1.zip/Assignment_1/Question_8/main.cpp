/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 9:02 PM
 * Assigment 1, Question 8
 */

// Total Price of 5 Items 
#include <iostream>
using namespace std;

int main() 
{
    float Item1, Item2, Item3, Item4, Item5, ItemTotal, Tax, Taxamount, Total;
    
    Item1 = 15.95;
    Item2 = 24.95;
    Item3 = 6.95;
    Item4 = 12.95;
    Item5 = 3.95;
    ItemTotal = Item1 + Item2 + Item3 + Item4 + Item5;
    Tax = 0.07; // Percentage Value 
    Taxamount = Tax * ItemTotal;
    Total = ItemTotal + Taxamount;
    
    cout << "Total price for the 5 items after tax is " << Total << endl;

    return 0;
}

