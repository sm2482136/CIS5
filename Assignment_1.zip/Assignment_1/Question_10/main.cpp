/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 9:20 PM
 * Assigment 1, Question 10
 */

// MPG
#include <iostream>
using namespace std;

int main() 
{
    float Gallons, Miles, MPG;
    
    Gallons = 15;
    Miles = 375;
    MPG = Miles/Gallons;
    
    cout << "The car's MPG is " << MPG << endl;    
    return 0;
}

