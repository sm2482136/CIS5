/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 18, 2018, 1:50 PM
 * Lab Assignment 4, Question 2 Dependent If statement 
 */

#include <iostream>
using namespace std;

int main() 
{
    //Variables
    float payRate, hrsWrkd, payChck, payChckwDT;
    //payChckwDT means Pay Check with Double Time
    
    //User inputs pay rate and hours worked
    cout<<"This Program will calculate your Pay Check.\n"
        <<"Please enter your hourly pay rate?  ";
    cin>>payRate;
    cout<<"Please enter how much hours you work in a week? ";
    cin>>hrsWrkd;
    
    //Equations 
    payChck=payRate*hrsWrkd;
    payChckwDT=40*payRate + ((2*payRate)*(hrsWrkd-40));
    
    //User finds out pay check amount
    if (hrsWrkd<0 || payRate<0)
        cout<<"Error! Please enter a positive numbers only";
    else if (hrsWrkd>=0 && hrsWrkd<=40)
        cout<<"Your Pay Check is "<<payChck;
    else if (hrsWrkd>40)
        cout<<"Your Pay Check is "<<payChckwDT;
    

    return 0;
}

