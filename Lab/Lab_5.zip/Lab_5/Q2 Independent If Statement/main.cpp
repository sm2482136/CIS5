/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 18, 2018, 2:23 PM
 * Lab Assignment 4, Question 2 Independent If statement 
 */

#include <iostream>
using namespace std;

int main() 
{
    //Variables
    float payRate, hrsWrkd, payChck, payChckwDT, Answer;
    //payChckwDT means Pay Check with Double Time
    
    
    //User inputs pay rate and hours worked
    cout<<"This Program will calculate your Pay Check.\n"
        <<"Please enter your hourly pay rate?  ";
    cin>>payRate;
    cout<<"Please enter how much hours you work in a week? ";
    cin>>hrsWrkd;
    
    //Error statement if user enters in negative numbers
    if (payRate<0 || hrsWrkd<=0)
        cout<<"Error! Enter Positive Numbers ONLY!\n"; 
    else
    {    
        //Equations 
        payChck=payRate*hrsWrkd;
        payChckwDT=40*payRate + ((2*payRate)*(hrsWrkd-40));
    
        //User finds out pay check amount
        if(hrsWrkd>=0 && hrsWrkd<=40)Answer=payChck;
        if(hrsWrkd>40)Answer=payChckwDT;
    
        cout<<"Your pay check is "<<Answer;
    }    

    return 0;
}

