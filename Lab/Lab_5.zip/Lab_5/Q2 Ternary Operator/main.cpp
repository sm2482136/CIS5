/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 18, 2018, 9:02 PM
 * Lab Assignment 4, Question 2 Ternary Operator
 */

#include <iostream>
using namespace std;

int main() 
{
    //Variables
   float payRate, hrsWrkd, payChck, payChckwDT, Answer;
    //payChckwDT means Pay Check with Double Time
 
    
    //User inputs pay rate and hours worked
    cout<<"This Program will calculate your Pay Check.\n"
        <<"Please enter your hourly pay rate?  ";
    cin>>payRate;
    cout<<"Please enter how much hours you work in a week? ";
    cin>>hrsWrkd;
    
    //Error statement if user enters in negative numbers
    if (payRate<0 || hrsWrkd<0)
        cout<<"Error! Enter Positive Numbers ONLY!\n";
    else
    {    //Equations 
        payChck=payRate*hrsWrkd;
        payChckwDT=40*payRate + ((2*payRate)*(hrsWrkd-40));
    
    
        //Maps input to output
        Answer=(hrsWrkd>=0 && hrsWrkd<=40)? payChck : payChckwDT;
    
        //User finds out pay check amount
        cout<<"Your pay check comes out to "<<Answer;
    }
  
            
    return 0;
}

