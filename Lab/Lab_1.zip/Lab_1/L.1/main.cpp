/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 9:20 PM
 * Lab 1
 */

#include <iostream>
using namespace std;

int main() 
{
    // Constants 
    float GP, OCPH, OCPL, FT, ST, SSTP;
    
    GP = 2.75; //Gas Price in Dollars/Gallon
    
    OCPH = .07; //Oil Company Profit High in Dollars/Gallon 
    
    OCPL = .065; //Oil Company Profit Low in Dollars/Gallon 
    
    FT = .184; //Federal Tax in Dollars/Gallon
    
    ST = .417; //State Tax in Dollars/Gallon
    
    SSTP = 0.0225; // States Sales Tax Percentage
    
    
    //Variables and Equations 
    float SST, TT, BP, PP, OCPR;
    
    BP = GP - FT - ST; //Base Price for a Gallon of Gas
    
    SST = GP * SSTP; //State Sales Tax for a Gallon of Gas
    
    TT= FT + ST + SST; // Total Tax for a Gallon of Gas
    
    PP = TT/BP; //Percentage Price Due Gas Tax 
    
    OCPR = (OCPH - OCPL); // Oil Company Profit Range
    
    
    cout << "1. The total tax on a gallon of gas is $" << TT << endl;
    cout << "2. The base price for a gallon of gas is $" << BP << endl;
    cout << "3. Percentage price due to gas tax is " << PP<< "%" << endl;
    cout << "4. Oil Company profit range for a gallon of is " << OCPR << "%" << endl;
    
         return 0;
}

