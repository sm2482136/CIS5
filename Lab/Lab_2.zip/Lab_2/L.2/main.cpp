/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 11, 2018, 8:49 PM
 * Lab 2
 */

#include <iostream>
using namespace std;

int main() 
{
    //Constants 
    float milBdgt, fedBdgt;
    
    milBdgt = 639.1e09f;    //Military Budget = 639.1 Billion 
    
    fedBdgt = 4.094e12f;    //Federal Budget  = 4.094 Trillion
    
    //Variables 
    float mlPrcnt; //Military Budget as a percentage of the Federal Budge
    
    //Equations 
    
    mlPrcnt = (milBdgt / fedBdgt) * 100;
    
    cout << "The Military Budget as a percentage of the Federal Budget is\n " 
         << mlPrcnt << "%" << endl;

    return 0;
}

