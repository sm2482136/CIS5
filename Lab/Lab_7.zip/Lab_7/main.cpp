/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 10:17 PM
 * Purpose Menu
 */

//System Libraries Here
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number function
#include <ctime>     //Time Library for random seed
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
using namespace std;


int main() {
    //Declare variables
    int probNum;
    
    //Loop on Menu and problems
    do{
    
        //Menu with input of choice
        cout<<"Choose from the following Menu"<<endl;
        cout<<"Problem 1 -> Gaddis_8thEd_Chap5_Prob1_SumofNumber"<<endl;
        cout<<"Problem 2 -> Gaddis_8thEd_Chap5_Prob3_OceanLevels"<<endl;
        cout<<"Problem 3 -> Gaddis_8thEd_Chap5_Prob4_CaloriesBurned"<<endl;
        cout<<"Problem 4 -> Gaddis_8thEd_Chap5_Prob5_MembershipFeesIncrease"<<endl;
        cout<<"Problem 5 -> Gaddis_8thEd_Chap5_Prob6_DistanceTraveled"<<endl;
        cout<<"Problem 6 -> Gaddis_8thEd_Chap5_Prob7_MathTutor"<<endl;
        cout<<"Problem 7 -> Gaddis_8thEd_Chap5_Prob16_SavingsAccountBalance"<<endl;
        cout<<"Problem 8 -> Savitch_8thEd_Chap4_Prob1_LiterstoGallons"<<endl;
        cout<<"Problem 9 -> Savitch_9thEd_Chap4_Prob4_99BottlesofBeer"<<endl;
        cout<<"Type 1 to 9 only"<<endl<<endl;
        cin>>probNum;
    
        //Output the results
        switch(probNum)
        {
            case 1: 
            {       //variables
                    int sum=0, 
                    num, // Number inputed 
                    i;    
    
    
                    //input
                    cout<<"Please Enter a Positive Integer. ";
                    cin>>num;
        
                    //No Negative Numbers
                    if (num<0)
                        cout<<"Error!!! Please Enter a Positive Integer. ";
                    else
                    {
                        //Loop
                        for(i=0; i<=num; i++)
                         sum+=i;
                        cout<<"The sum of all number from 0 to the number "
                        <<"you chose is " <<sum;   
                    }    
       
                break;
            }    
            case 2:
            {
                //Variables
                int year=2018;
                float risingperyear=1.5,
                totalrising=0;  
                cout<<"Year     Ocean Level Riseing Per year\n";
                //Loop
                for (year; year<=2043; year++)
                {
                    cout<< year;
                    totalrising+=risingperyear;
                    cout<<"     "<<totalrising<<" \n";
                }
                
                break;
            }
            case 3: 
            {
                //Variables
                float CaloriesBurnedPerMin=3.6,
                TotalCaloriesBurned,  
                Mins=5;
            
    
                //Heading
                cout<<"Calroies burnt every 5 Minutes on Teadmill\n";
                cout<<"\nMinutes     Calories Burned\n  ";
    
                //Loop        
                for(Mins; Mins<=30; Mins+=5)
                {
                    cout<<Mins;
                    TotalCaloriesBurned= CaloriesBurnedPerMin * Mins;
                    cout<<"           "<<TotalCaloriesBurned<<"\n ";
                }
                break;
            }
            case 4: 
            {
                //Variables
               float Charges=2500,
                     year=2009,
                     IncreaseFeePercentage=.04;
           
    
                //Heading 
                cout<<"See the Chart Below the Yearly"
                    <<" Membership Fee\n";
                cout<<"\nYear       Fee Amount\n";
    
                //Loop
                for (year; year<=2014; year++)
                { 
                    cout<<year;
                    Charges+=(Charges*IncreaseFeePercentage);
                    cout<<"       "<<Charges<<"\n";
                }     
                break;
            }
            case 5: 
            {
                int MPH,
                    Hours,
                    Distance,
                    i=1;    
    
                //Input
                cout<<"What is the speed of the vehicle (in miles per hour)? ";
                cin>>MPH;
                cout<<"\n";
                cout<<"How many hours did the vechicle travel for? ";
                cin>>Hours;
    
                //No Negative MPG
                if(MPH<0)
                    cout<<"Error!!! Enter Postive Numbers for the Speed";
                //No hours less than 1
                else if (Hours<1)
                     cout<<"Error!!! Enter Number Greater than 1 for the time traveled";
                else
                {
                    //Heading
                     cout<<"Hours      Distance Traveled\n";
        
                    //loop
                    for(i ; i<=Hours; i++)
                    {
                         Distance=MPH*i;
                        cout<<i;
                        cout<<"           "<<Distance<<"\n";      
                    }    
           
        
                }    
                ;break;
            }
            case 6: 
            {
                //Loop the process
                char answer;
                do{
                //Declare Variables
                char choice;//Character used for switch

                //Input Data
                //Ask the user what they would like to calculate
                cout<<"Math Game"<<endl;
                cout<<"Which operation would you like to play?"<<endl;
                cout<<"Type 1 for addition problem"<<endl;
                cout<<"Type 2 for subtraction problem"<<endl;
                cout<<"Type 3 for multiplication problem"<<endl;
                cout<<"Type 4 for division problem"<<endl;
                cout<<"Type 5 to quit the problem"<<endl;
                cin>>choice;
    
                //Process the Data
                switch(choice)
                {
                    case'1':
                    {
                
                        // Variables
                        srand(static_cast<unsigned int>(time(0)));
                        //Declare variables
                        float random1, random2, result;
                        float answer;

                        //Input 
                        random1=rand()%900+100;//Random 3 digit number
                        random2=rand()%900+100;//Random 3 digit number
                        result=random1+random2;

                        //Display the problem
                        cout<<"Calculate the result of the following problem!"<<endl;
                        cout<<"Line up and type the result"<<endl;
                        cout<<"   "<<random1<<endl;
                        cout<<" + "<<random2<<endl;
                        cout<<"-------"<<endl;
                        cin>>answer;
                        //Output and Process the Data
                        if(result-answer==0)
                        {
                            cout<<endl<<"Your answer is correct!"<<endl;
                         }
                
                        else
                        {
                            cout<<endl<<"Wrong the answer was "<<result<<endl;
                        }
                        
                        break;
                    }
                    case'2':
                    {
                        //Variables
                        srand(static_cast<unsigned int>(time(0)));
                        // variables
                        float random1, random2, result;
                        float answer;

                        //Input 
                        random1=rand()%900+100;//Random 3 digit number
                        random2=rand()%900+100;//Random 3 digit number
                        result=random1-random2;

                        //Display the problem
                        cout<<"Calculate the result of the following problem!"<<endl;
                        cout<<"Line up and type the result"<<endl;
                        cout<<"   "<<random1<<endl;
                        cout<<" - "<<random2<<endl;
                        cout<<"-------"<<endl;
                        cin>>answer;
                
                        //Output
                        if(result-answer==0) 
                        {
                            cout<<endl<<"Your answer is correct!"<<endl;
                        } 
                
                        else
                        {
                            cout<<endl<<"Wrong the answer was "<<result<<endl;
                         }
                
                        break;
                    }
                    case '3':
                    {
                        // Variables
                        srand(static_cast<unsigned int>(time(0)));
                        // variables
                        float random1, random2, result;
                        float answer;

                        //Input 
                        random1=rand()%90+10;//Random 2 digit number
                        random2=rand()%9+1;//Random 1 digit number
                        result=random1*random2;

                        //Output
                        cout<<"Calculate the result of the following problem!"<<endl;
                        cout<<"   "<<random1<<"*"<<random2<<endl;
                        cin>>answer;

                        //Output and Process the Data
                        if(result==answer)
                        {
                            cout<<endl<<"Your answer is correct!"<<endl;
                        }
                
                         else
                        {
                            cout<<endl<<"Wrong the answer was "<<result<<endl;
                        }
                
                        break;

                    }
                    case '4':
                    {
                        //Declare Variables
                        srand(static_cast<unsigned int>(time(0)));
                        //Declare variables
                        float random1, random2, result;
                        float answer;

                        //Input data
                        random1=rand()%90+10;//Random 2 digit number
                        random2=rand()%9+1;//Random 1 digit number
                        cout<<fixed<<setprecision(2)<<endl;
                        result=random1/random2;

                        //Display the problem
                        cout<<"Calculate the result of the following problem!"<<endl;
                        cout<<"   "<<random1<<'/'<<random2<<endl;
                        cin>>answer;

                        //Output and Process the Data
                        if(result==answer)
                        {
                            cout<<endl<<"Your answer is correct!"<<endl;
                        }
                
                        else
                        {
                            cout<<endl<<"Wrong the answer was "<<result<<endl;
                        }
                
                        break;
                    }
                    case '5':
                    {
                        cout<<"The program has quit"<<endl;
                        break;
                    }
                    default:cout<<"Not an option in the menu"<<endl;
                }
                cout<<"Would you like to run the program again?"<<endl;
                cout<<"Type Y to run"<<endl;
                cin>>answer;
    
                }while(answer=='Y'||answer=='y'); 
            break;
            }
            case 7: 
            {
                //Declare Variables
                float annRate,//Annual interest rate
                startBal,//Starting balance in savings account
                mnthsPas,//Months that have passed since the account was established 
                monIrate;//Monthly interest rate  
    
                //Input 
                cout<<"Please enter the annual interest rate";
                cout<<", starting balance, and the number of months"<<endl;
                cin>>annRate>>startBal>>mnthsPas;
    
                //Process the input
                annRate/=100.0f;//Convert percent to decimal
                monIrate=annRate/12.0f;//
    
                //Loop Variables
                float monyDep=0,//Moneys deposited
                finBal=0,//Balance at the end of the period of time
                intEarn=0,//Interest the money has earned
                newBal=0,//New balance
                totDep=0,//Total amount deposited 
                totWit=0,//Total amount withdrawn
                totIrate=0,//Total interest earned
                monyWit=0;//Moneys withdrawn
                int month=1,num=1;
    
                //Loop
                do
                {
        
                    cout<<"Enter moneys deposited for month "<<num<<endl;
                    cin>>monyDep;//Money deposited into the account
                    while(monyDep<0)
                    {
                        cout<<"Enter a valid amount deposited for month "<<num<<endl;
                        cin>>monyDep;
                    }
                    cout<<"Enter moneys withdrawn for month "<<num<<endl;
                    cin>>monyWit;//Money taken out of the account
                    while(monyWit<0)
                    {
                        cout<<"Enter a valid amount withdrawn for month "<<num<<endl;
                        cin>>monyWit;
                    }
                    newBal=intEarn+startBal+monyDep+totDep-totWit-monyWit;//Balance after monthly transactions
                    intEarn=monIrate*newBal;//Interest earned at the end of the month
                    totIrate+=intEarn;//Total amount of interest earned
                    totDep+=monyDep;//Total amount deposited
                    totWit+=monyWit;//Total amount withdrawn
                    num++;
                    month++;

                }
                while(month<=mnthsPas);
                    finBal=totIrate+startBal+totDep-totWit;
                    int pennies=finBal*100+0.5;//Round to the nearest penny
                    finBal=pennies/100.0f;
                    cout<<fixed<<setprecision(2)<<showpoint;
                    cout<<"Final balance in the account is $ "<<setw(6)<<finBal<<endl;
                    cout<<"Total amount of withdrawals is  $ "<<setw(6)<<totWit<<endl;
                    cout<<"Total amount of deposits is     $ "<<setw(6)<<totDep<<endl;
                    cout<<"Total interest earned is        $ "<<setw(6)<<totIrate<<endl;
                break;
            }
            case 8: 
            {
                // Variables
                float litGas;//Number of Liters of Gas consumed by the car
                float galGas;//liters converted into Gallons
                int nMiles;//Number Of Miles Car was driven
                int gasMil;//miles per Gallon
    
    
                //Input 
                cout<<"Input the Number of Liters car consumed"<<endl;
                cin>>litGas;
                cout<<"Input the Number of Miles car has been Driven"<<endl;
                cin>>nMiles;
    
                //Equations
                galGas=0.264*litGas;
                gasMil=nMiles/galGas;
    
                //Output
                cout<<gasMil<<" Miles Per Gallon "<<endl;
                break;
            }
            case 9: 
            {
                //Loop
                for(int bottles=99;bottles>=1;bottles--)
                {
                    //Calculate tens and Ones
                    int nTens=(bottles-bottles%10)/10;//Number of 10's
                    int nOnes=bottles-nTens*10;//Number of Ones
                    for(int times=1;times<=3;times++)
                    {
                        if(times==3)
                        {
                            int temp=bottles-1;
                            nTens=(temp-temp%10)/10;
                            nOnes=temp-nTens*10;
                        }
                        switch(nTens)
                        {
                            case 9:cout<<"Ninety ";break;
                            case 8:cout<<"Eighty ";break;
                            case 7:cout<<"Seventy";break;
                            case 6:cout<<"Sixty";break;
                            case 5:cout<<"Fifty";break;
                            case 4:cout<<"Forty";break;
                            case 3:cout<<"Thirty";break;
                            case 2:cout<<"Twenty";break;
                            case 1:
                            {
                                switch(nOnes)
                                {
                                    case 1:cout<<"Eleven";break;
                                    case 2:cout<<"Twelve";break;
                                    case 3:cout<<"Thirteen";break;
                                    case 4:cout<<"Fourteen";break;
                                    case 5:cout<<"Fifteen";break;
                                    case 6:cout<<"Sixteen";break;
                                    case 7:cout<<"Seventeen";break;
                                    case 8:cout<<"Eighteen";break;
                                    case 9:cout<<"Nineteen";break;       
                                }
                            }
                        }
                        if(nTens!=1)
                        {
                            switch(nOnes)
                            {
                                case 0:if(nTens==0)cout<<"Zero";break;
                                case 1:cout<<"One";break;
                                case 2:cout<<"Two";break;
                                case 3:cout<<"Three";break;
                                case 4:cout<<"Four";break;
                                case 5:cout<<"Five";break;
                                case 6:cout<<"Six";break;
                                case 7:cout<<"Seven";break;
                                case 8:cout<<"Eight";break;
                                case 9:cout<<"Nine";break;
                            }
                        }
                        if(times==1||times==3)cout<<" bottles of beer on the wall "<<endl;
                        else if(times==2)
                        {
                            cout<<" Bottles of Beer "<<endl;
                            cout<<"You take one down you pass it around "<<endl;
                        }
                    }       
                    cout<<endl;
                } break;
            }
            default:cout<<"You choose to exit"<<endl;
        }
    }while(probNum>=1&&probNum<=9);
   
    //Exit
    return 0;
}

