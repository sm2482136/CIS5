/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 9:28 PM
 * Assigment 1, Question 12
 */

// How Much Acres in Land 
#include <iostream>
using namespace std;

int main()  
{
    float Acre, Land, TotalAcres; // All in square feet
    
    Acre = 43560;
    Land = 391876;
    TotalAcres = Land/Acre;
    
    cout << "Total amount of acres in the tract of land is " << TotalAcres << endl;
            
            
    return 0;
}

