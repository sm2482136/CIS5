/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 8:34 PM
 * Assigment 1, Question 3
 */

// Total sales Tax 
#include <iostream>
using namespace std;

int main() 
{
    float SST, CST, Item, TotalTaxOnItem;
    
    SST = 0.04; // Percentage Value
    CST = 0.02; // Percentage Value 
    Item = 95; // In dollars 
    TotalTaxOnItem = (SST + CST) * Item;
    
    cout << "Total tax on a Item that is 95 dollars is " << TotalTaxOnItem << endl;
    
    return 0;
}

