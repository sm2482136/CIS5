/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 8, 2018, 9:37 PM
 * Assigment 1, Question 15
 */

// Triangle Pattern 
#include <iostream>
using namespace std;

int main()
{
    cout <<"   *" <<endl;
    cout <<"  ***" << endl;
    cout <<" *****" << endl;
    cout <<"*******" << endl;

    return 0;
}

