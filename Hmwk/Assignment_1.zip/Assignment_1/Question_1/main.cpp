/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 * Created on January 8, 2018, 7:59 PM
 * Question 1
 */

// Sum of Two Numbers 
#include <iostream>
using namespace std;

int main() 
{
    float fifty, onehundred, sum;
    
    fifty = 50;
    onehundred = 100;
    sum = fifty + onehundred;
            
    cout << sum << endl;
    
    return 0;
}

