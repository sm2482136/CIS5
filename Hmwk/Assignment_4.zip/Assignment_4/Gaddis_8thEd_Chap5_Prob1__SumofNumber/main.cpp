/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 2:02 PM
 * Purpose Sum of Numbers 
 */

#include <iostream>  
using namespace std;

int main()  
{
    //variables
    int sum=0, 
        num, // Number inputed 
        i;    
    
    
        //input
        cout<<"Please Enter a Positive Integer. ";
        cin>>num;
        
        //No Negative Numbers
        if (num<0)
            cout<<"Error!!! Please Enter a Positive Integer. ";
        else
        {
            //Loop
            for(i=0; i<=num; i++)
                sum+=i;
            cout<<"The sum of all number from 0 to the number "
            <<"you chose is " <<sum;   
        }    
        
      
                
       
    
   

    return 0;
}

