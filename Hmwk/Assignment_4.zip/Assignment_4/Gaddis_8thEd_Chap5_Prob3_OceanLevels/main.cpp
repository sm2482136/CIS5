/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 6:42 PM
 * Purpose Ocean Levels 
 */

#include <iostream>  
using namespace std;

int main() 
{
    //Variables
    int year=2018;
    float risingperyear=1.5,
          totalrising=0;  
    cout<<"Year     Ocean Level Riseing Per year\n";
    //Loop
    for (year; year<=2043; year++)
    {
        cout<< year;
        totalrising+=risingperyear;
        cout<<"     "<<totalrising<<" \n";
       
        
        
           
        
      
    }    
            

    return 0;
}

