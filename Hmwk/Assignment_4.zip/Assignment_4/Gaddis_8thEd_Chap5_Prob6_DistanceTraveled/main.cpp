/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 7:51 PM
 * Purpose Distance Traveled 
 */

#include <iostream>  
using namespace std;

int main()
{
    int MPH,
        Hours,
        Distance,
        i=1;    
    
    //Input
    cout<<"What is the speed of the vehicle (in miles per hour)? ";
    cin>>MPH;
    cout<<"\n";
    cout<<"How many hours did the vechicle travel for? ";
    cin>>Hours;
    
    //No Negative MPG
    if(MPH<0)
        cout<<"Error!!! Enter Postive Numbers for the Speed";
    //No hours less than 1
    else if (Hours<1)
        cout<<"Error!!! Enter Number Greater than 1 for the time traveled";
    else
    {
        //Heading
        cout<<"Hours      Distance Traveled\n";
        
        //loop
        for(i ; i<=Hours; i++)
        {
           Distance=MPH*i;
           cout<<i;
           cout<<"           "<<Distance<<"\n";      
        }    
           
        
    }    

    return 0;
}

