/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 9:08 PM
 * Purpose Liters to Gallons
 */

#include <iostream>
using namespace std;

int main()   
{
    // Variables
    float litGas;//Number of Liters of Gas consumed by the car
    float galGas;//liters converted into Gallons
    int nMiles;//Number Of Miles Car was driven
    int gasMil;//miles per Gallon
    
    
    //Input 
    cout<<"Input the Number of Liters car consumed"<<endl;
    cin>>litGas;
    cout<<"Input the Number of Miles car has been Driven"<<endl;
    cin>>nMiles;
    
    //Equations
    galGas=0.264*litGas;
    gasMil=nMiles/galGas;
    
    //Output
    cout<<gasMil<<" Miles Per Gallon "<<endl;
    
    return 0;
}


