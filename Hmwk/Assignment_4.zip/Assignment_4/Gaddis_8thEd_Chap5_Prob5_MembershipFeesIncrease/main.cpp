/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 7:25 PM
 * Purpose Membership Fees Increase 
 */

#include <iostream>  
using namespace std;

int main() 
{
    //Variables
    float Charges=2500,
          year=2009,
          IncreaseFeePercentage=.04;
           
    
    //Heading 
    cout<<"See the Chart Below the Yearly"
        <<" Membership Fee\n";
    cout<<"\nYear       Fee Amount\n";
    
    //Loop
    for (year; year<=2014; year++)
    { 
        cout<<year;
        Charges+=(Charges*IncreaseFeePercentage);
        cout<<"       "<<Charges<<"\n";
    }    
    

    return 0;
}

