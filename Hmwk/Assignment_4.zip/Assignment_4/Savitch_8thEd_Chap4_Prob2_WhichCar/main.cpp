/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 4:01 PM
 * Purpose Which Car is Most Fuel Efficent 
 */

#include <iostream> 
#include <iomanip>
using namespace std;

int main() 
{
    // Variables
    float litGas;//Number of Liters of Gas consumed by the car
    float galGas;//liters converted into Gallons
    int nMiles;//Number Of Miles Car was driven
    float gasMil;//Miles per Gallon of first car
    float secLit;//Number of liters of has 2nd car consumed
    int secMil;//Number of miles second car was driven
    float sgalGas;//liters converted to gallons of second car
    float sgasMil;//Miles per gallon of second car
    
    //Input 
    cout<<"Input the Amount of Liters First car Consumed"<<endl;
    cin>>litGas;
    cout<<"Input the Number of Miles First car has been Driven"<<endl;
    cin>>nMiles;
    cout<<"Input the Amount of Liters the Second car Consumed"<<endl;
    cin>>secLit;
    cout<<"Input the Number of Miles the Second car has been Driven"<<endl;
    cin>>secMil;
    
    //Equations
    galGas=0.264*litGas;
    sgalGas=0.264*secLit;
    gasMil=nMiles/galGas;
    sgasMil=secMil/sgalGas;
    
    if (gasMil>sgasMil)
        cout<<"First car is the Most Fuel Efficient"<<endl;
    else
        cout<<"Second car is the Most Fuel Efficient"<<endl;
    
    
          
    
    //Output 
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    cout<<gasMil<<" Miles Per Gallon : First Car"<<endl;
    cout<<sgasMil<<" Miles Per Gallon : Second Car"<<endl;
    

    return 0;
}

