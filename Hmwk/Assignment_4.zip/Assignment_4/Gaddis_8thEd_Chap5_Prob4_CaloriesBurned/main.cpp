/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 22, 2018, 7:08 PM
 * Purpose Calories Burned 
 */

#include <iostream>  
using namespace std;

int main()
{
    //Variables
    float CaloriesBurnedPerMin=3.6,
          TotalCaloriesBurned,  
          Mins=5;
            
    
    //Heading
    cout<<"Calroies burnt every 5 Minutes on Teadmill\n";
    cout<<"\nMinutes     Calories Burned\n  ";
    
    //Loop        
    for(Mins; Mins<=30; Mins+=5)
    {
        cout<<Mins;
        TotalCaloriesBurned= CaloriesBurnedPerMin * Mins;
        cout<<"           "<<TotalCaloriesBurned<<"\n ";
    }
            

    return 0;
}

