/*
 * File:   main.cpp
 * Author: Shanilka Jehan Mapatuna 
 * Created on February 3 2018, 5:30 PM
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

void compute_coins(int, int&, int&);
// Computes coins with a call by value; int, and two call by reference; int,int
int main ()
{
	using namespace std; 
	int coin_value = 0, num = 0, amount_left = 0;
	char ans;
	do 
	{
	do 
	{
		cout << "Please enter an amount of cents between 1 and 99.\n";
		cin >> amount_left;
		
	} while (amount_left < 1 || amount_left > 99);
	// If amount of cents is between 1 and 99 then the rest of function is executed.

compute_coins(25, num, amount_left);
cout << "there is " << num << " Quarters " << endl;
//
compute_coins(10, num, amount_left);
cout << "there is " << num << " dimes " << endl;

compute_coins(1, num, amount_left);
cout << "there is " << num << " pennys " << endl;

cout << "Type y to go again or n to exit " << endl;

cin >> ans;
	} while (ans == 'y' || ans == 'Y');
 
	// Allows user to stay on screen without having to keep reopen the program through debugging. User can select yes to continue or anything else to exit. 
}


void compute_coins(int coin_value, int& num, int& amount_left)
{
num = amount_left / coin_value;
amount_left = amount_left % coin_value;
}
