/*
 * File:   main.cpp
 * Author: Shanilka Jehan Mapatuna
 * Created on February 2, 2018, 11:30 AM
 * Purpose:  Calculating Rainfall
 */

//system libraries
# include <iostream>
# include <cstring>
using namespace std;

int main () {	
    float avgRain = 0;
    float rainSum = 0;
    
    int highestCount = 0; 
    int lowestCount = 0; // 1 (Febuary : 40)
    int count = 0; // 2

    float monthlyTotals[11];
    string monthNames[] = {"January","Febuary","March","April","May","June","July","August","September","October","November","December"};
    
    cout << "Please enter the amount of rainfall for each month, in cm "<<endl;
    for (count = 0; count <= 11; count++)
    {
            cout<< monthNames[count] << " : ";
            cin>> monthlyTotals[count];
            while (monthlyTotals[count] < 0)
            {
                    cout << "Please reenter a positive number for the month of " << monthNames[count] << endl;
                    cin >> monthlyTotals[count];
            }
            // Add em all up to get the average later
            rainSum = rainSum + monthlyTotals[count];
            
            // Track the highest
            if (monthlyTotals[count] > monthlyTotals[highestCount]) {
                highestCount = count;
            }
            // Track the lowest
            if (monthlyTotals[count] < monthlyTotals[lowestCount]) {
                lowestCount = count;
            }
    }
    
    avgRain = rainSum / 12;
    for (count = 0; count <=11; count++)
    {	
        cout << monthNames[count] << "\t" << monthlyTotals[count] << endl;
    }
    cout <<rainSum<< " centimeters of total rainfall for the year\n" <<avgRain<< " is the average for the year.\n";
    cout <<monthNames[highestCount]<< " is the highest rainfall month." << endl;
    cout <<monthNames[lowestCount]<< " is the lowest rainfall month." << endl;
    return 0;
}

