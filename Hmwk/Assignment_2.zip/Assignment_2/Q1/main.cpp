/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 11, 2018, 8:30 PM
 * Assignment 2 Question 1, Gaddis
 */

//MPG
#include <iostream>
using namespace std;

int main()
{
    double MPG, GTC, MT;
    
    // GTC means Gas Tank Capacity 
    // MT means Miles Traveled 
    // MPG means Miles per Gallon 
    //Equations
    
    
    cout << "Enter the amount of gas your car holds ";
    cin >> GTC;
    cout << "Enter the distance traveled on a full tank of gas in miles ";
    cin >> MT;
    
    MPG = MT/GTC;
    
    cout << "Your MPG is " << MPG;
    

    return 0;
}

