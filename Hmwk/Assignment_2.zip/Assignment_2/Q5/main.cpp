/*
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 9:45 PM
 * Assignment 2 Question 5, Gaddis
 */

//Male and Female Percentage
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    //constant variables
    float males, females,totStd, malPrct,fPrct;

    
    cout<<"How many males are in the classroom? "<< endl;
    cin>>males;
    cout<<"How many females are in the classroom? "<< endl;
    cin>>females;
    
    //Equations
    
    totStd = males + females;               //Total amount of students in a classroom
    malPrct = (males / totStd) * 100;       //Percentage of males in classroom
    fPrct = (females / totStd) * 100;       //Percentage of females in classroom
    
    cout<< "The percentage of males in the classroom is: %"<< setprecision(3)<< malPrct<< endl; 
    cout<< "The percentage of females in the classroom is: %"<< setprecision(3)<< fPrct <<endl; 
    
    return 0;
}

