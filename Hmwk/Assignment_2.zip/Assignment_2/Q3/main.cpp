/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 9:12 PM
 * Assignment 2 Question 3, Gaddis
 */

//Test Scores Average 
#include <iostream>
#include <iomanip>  
using namespace std;

int main()
{ 
    //Variables
    float T1, T2, T3, T4 ,T5, AvgTS;
    // T1-T5 mean Test score of the corresponding number next to the "T"
    // AvgTS means the average of all the test scores 
    
    cout << "Enter test number 1 score. ";
    cin >> T1;
    cout << "Enter test number 2 score. ";
    cin >> T2;
    cout << "Enter test number 3 score. ";
    cin >> T3;
    cout << "Enter test number 4 score. ";
    cin >> T4;
    cout << "Enter test number 5 score. ";
    cin >> T5;
    
    //Equations 
   
    AvgTS = (T1 + T2 +T3 +T4 +T5)/5;
    
    cout << "Your Test average is ";
    cout << fixed << setprecision(1) << AvgTS << endl;
    

    return 0;
}

