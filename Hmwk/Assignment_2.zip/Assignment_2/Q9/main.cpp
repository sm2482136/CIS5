/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 10:00 PM
 * Assignment 2 Question 12, Gaddis
 */

//Calories 
#include <iostream>
#include <iomanip>  
using namespace std;

int main() 
{
    float C, TCal;
    // C means cookies 
    // TCal mean total Calories 
    
    cout << "How many cookies did you eat? ";
    cin >> C;
    
    //Equation
    
    TCal = C * 100;
    
    cout << "Your total calories for eating " << C << " cookies is ";
    cout << TCal;

    return 0;
}

