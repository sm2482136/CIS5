/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 11:13 PM
 * Assignment 2 Question 11, Gaddis
 */

//Calories 
#include <iostream>
#include <iomanip>  
using namespace std;

int main() 
{
    float loanpayment, insurance, gas, oil, tires, maintenance, Monthlycost, Annualcost;
    
    cout << "Automobile Expenses" <<endl;
            
    cout << " \nHow much do you pay a month on your loan? ";
    cin >> loanpayment;
    
    cout <<  " How much you pay a month on insurance? ";
    cin >> insurance;
    
    cout << " How much you pay a month on gas? ";
    cin >> gas;
    
    cout << " How much you pay a month on oil ? ";
    cin >> oil;
    
    cout << " How much you pay a month on tires ? ";
    cin >> tires;
    
    cout << " How much you pay a month on maintenance ? ";
    cin >> maintenance;
    
    //Equation 
    
    Monthlycost = loanpayment + insurance + gas + oil + tires + maintenance;
    
    Annualcost = Monthlycost * 12;
            
            
            
    cout << "Your monthly cost for your automobile is $";
    cout << Monthlycost << endl;
    cout << "Your annual cost for your automobile is $";
    cout << Annualcost << endl;
            
    

    return 0;
}

