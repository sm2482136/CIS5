/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 9:21 PM
 * Assignment 2 Question 4, Gaddis
 */

//Avg Rainfall
#include <iostream>
#include <iomanip>  
using namespace std;

int main(){
    
    string M1, M2, M3;
    //Name of Months 
    //M1 means Month 1 
    //M2 means Month 2
    //M3 means Month 3
    
    //Variables 
    float M1R, M2R, M3R, AvgRF;
    // M1R means the amount of rainfall in Month 1 in inches
    // M2R means the amount of rainfall in Month 2 in inches
    // M3R means the amount of rainfall in Month 3 in inches
    // AvgRF means average rainfall from Months 1-3 in inches
    
    cout << "Enter the names of the 3 months ";
    cin >> M1;
    cout<< ", ";
    cin >> M2;
    cout<< ", ";
    cin >> M3;
    
    cout << "Enter the amount of rainfall that happened in ";
    cout << M1;
    cout << " in inches ";
    cin >> M1R;
    cout << "Enter the amount of rainfall that happened in ";
    cout << M2;
    cout << " in inches ";
    cin >> M2R;
    cout << "Enter the amount of rainfall that happened in ";
    cout << M3;
    cout << " in inches ";
    cin >> M3R;
    
    //Equation 
    
    AvgRF = (M1R + M2R + M3R)/3;
    
    cout << "The average rain fall for ";
    cout << M1 <<", " << M2 <<", and " << M3;
    cout << " is " << AvgRF << endl;
    
            
    
    
           
    
    
   
    
            
            

    return 0;
}

