/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 10:30 PM
 * Assignment 2 Question 12, Gaddis
 */

//Dollars to Japanese Yens
// Dollars to Euros
#include <iostream>
#include <iomanip>  
using namespace std;

int main()  
{ 
    float D2Y,D2E, YA, EA; 
    //D2Y means Dollar Amount for Yen 
    //D2E means Dollar Amount exchange for Euro
    //YA means Japanese Yen Amount 
    //EA mean Euro Amount
    
    cout << "How much dollars do you want to convert to Japanese Yens? ";
    cin >> D2Y;
    cout << "How much dollars do you want to convert to Euros? ";
    cin >> D2E;
    
    //Equations 
    
    YA = D2Y * 98.93;
    
    EA = D2E * 0.74;
    
    cout << D2Y << " dollars Exchange to ";
    cout<< fixed << setprecision(2) << YA << " Japanese Yens"<< endl;
    cout << D2E << " dollars Exchange to ";
    cout<< fixed << setprecision(2) << EA << " Euros" << endl;
            
    

    return 0;
}

