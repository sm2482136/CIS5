/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 10:10 PM
 * Assignment 2 Question 12, Gaddis
 */

//Celsius to Fahrenheit
#include <iostream>
#include <iomanip>  
using namespace std;

int main() 
{
    float F, C;
    //F is the Fahrenheit temperature
    //C is the Celsius temperature
    
    cout << "Enter the temperature in celsius that you wish to covernt to Fahrenheit ";
    cin >> C;
    
    //Equation
    
    F = ((9 * C)/5) +32;
    
    cout << "The temperature in Fahrenheit is ";
    cout << F << endl;
   
    
    
    
    return 0;
}

