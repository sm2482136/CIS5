/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 8:08 PM
 * Assignment 3 Question 8, Gaddis
 */

//Book Club Points
#include <iostream> 
using namespace std;

int main() 
{
    //variables
    int BooksPurchased;
    
    //User inputs number of books he/she bought
    cout<< "How much book did you buy this month? ";
    cin >> BooksPurchased;
    
    //User finds out how much Points he/she earned this month
    if (BooksPurchased == 0)
        cout<< "Sorry you earned 0 points";
    else if (BooksPurchased == 1)
        cout<< "You earned 1 points";
    else if (BooksPurchased == 2)
        cout<< "Keep it up!! You earned 15 points";
    else if (BooksPurchased == 3)
        cout<< "You earned 30 points!!";
    else if (BooksPurchased >= 4)
        cout<< "!!!You earned 60 points!!!";
    
    return 0;
}

