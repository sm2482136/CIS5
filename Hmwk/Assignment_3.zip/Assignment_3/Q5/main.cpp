/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 6:31 PM
 * Assignment 3 Question 5, Gaddis
 */

//Body Mass Index 
#include <iostream> 
#include<cmath>
using namespace std;

int main() 
{
    // Variables
    float Weight, Height, BMI;
    
    //User Inputs Weight and Hight
    cout << "Please enter your weight in pounds ";
    cin >> Weight;
    cout << "Please Enter your height in inches ";
    cin >> Height;
    
    //Equations 
    BMI = (Weight * 703)/(pow(Height,2));
    
    //User finds out if their weight is Good or bad
    
    if (BMI > 18.5 && BMI < 25)
        cout << "You are at optimal weight!!!";
    else if (BMI < 18.5)
        cout << "You are underweight.";
    else if (BMI > 25) 
        cout << "You are overweight";
                
    
    return 0;
}

