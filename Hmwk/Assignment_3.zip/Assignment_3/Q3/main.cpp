/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 5:14 PM
 * Assignment 3 Question 3, Gaddis
 */

//Magic Dates
#include <iostream> 
using namespace std;

int main() 
{
    //variables
    int day, month, year, magic;
    //magic= 2 digit day times the month
    
    //user inputs day, month, and year 
    cout << "Enter the two digit day, month and year"<< endl;
    cin >> day >> month >> year;
    
    //equations 
    magic = day * month;
    
    //user finds out if date is magic or not 
    if (magic == year)
        cout <<"The date is magic";
    else
        cout <<"The date is not magic";
                
        
    return 0;
}

