/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 5:30 PM
 * Assignment 3 Question 6, Gaddis
 */

//Mass and Weight
#include <iostream> 
using namespace std;

int main()  
{
    //Variables 
    float Mass, Weight;
    
    //User enters Mass
    cout << "Enter the Mass of the object, so "
         <<"I can find the object's weight in newtons.\n";
    cin >> Mass;
    
    //Equations
    Weight = Mass * 9.8;
    
    //User finds out weight 
    if (Weight > 1000)
    {   cout << "The weight of the object is "
             << Weight << ".\n";
        cout <<"This is too heavy.";
    }
    else if (Weight < 10)
    {   cout << "The weight of the object is "
             << Weight << ".\n";
        cout <<"This is too light.";
    }
    else
    {    cout << "The weight of the object is "
             << Weight << ".";
    }
    return 0;
}

