/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 1:44 PM
 * Assignment 3 Question 1, Gaddis
 */

//Minimum and Maximum
#include <iostream>  
using namespace std;

int main() 
{
    //Variables 
    float number1, number2;
    //to store two numbers user inputs
    
    //User input numbers
    cout << "Please input two numbers \n";
    cin >> number1 >> number2;
    
    //Determine what number is bigger
    if (number1 > number2)
        cout << number1 << " is larger and "
             << number2 << " is smaller";
    else if (number2 > number1)
        cout << number2 << " is larger and "
             << number1 << " is smaller";
    else
        cout << "Both numbers are equal";
        
                

    return 0;
}

