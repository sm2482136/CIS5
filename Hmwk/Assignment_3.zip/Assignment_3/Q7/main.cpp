/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 6:02 PM
 * Assignment 3 Question 7, Gaddis
 */

//Time Calculator
#include <iostream> 
using namespace std;

int main()
{
    // variables
    float Seconds, Minutes, Hours, Days;
    
    //User Inputs Seconds
    cout << "Please Enter number of seconds ";
    cin >> Seconds;
    
    //Equations 
    Minutes = Seconds/60;
    Hours = Seconds/3600;
    Days = Seconds/86400;
    
    //The User finds out the Conversions of Seconds
    
    if (Seconds >= 60 && Seconds < 360)
    {   cout <<"The Number of Minutes"    
             << " in the seconds you entered is "
             << Minutes;
    }
    else if (Seconds >= 3600 && Seconds < 86400)
    {   cout << "The Number of Hours"    
             << " in the seconds you entered is "
             << Hours;
    }
    else if (Seconds >= 86400)
    {   cout << "The Number of Days"    
             << " in the seconds you entered is "
             << Days;
    }
    return 0;
}

