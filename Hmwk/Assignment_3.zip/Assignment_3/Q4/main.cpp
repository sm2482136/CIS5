/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 4:47 PM
 * Assignment 3 Question 4, Gaddis
 */

//Areas of Rectangles
#include <iostream>  
using namespace std;

int main()  
{
    // Variables
    float length1, length2, width1, width2, area1, area2;
    // length, width, and area for 2 rectangle 
    
    //user inputs lengths and widths
    cout <<"Enter the length and width for rectangle 1: ";
    cin >> length1 >> width1;
    cout <<"Enter the length and width for rectangle 2: ";
    cin >> length2 >> width2;
    
    //Equations 
    area1 = length1 * width1;
    area2 = length2 * width2;
    
    //Tell the user which rectangle is bigger 
    
    if (area1 > area2)
        cout << "Rectangle 1 has a larger area\n";
    
    else if (area1 < area2)
        cout << "Rectangle 2 has a larger area\n";
    
    else
        cout << "Rectangle 1 and Rectangle 2 have equal areas\n";
    
            
    return 0;
}

