/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 6:43 PM
 * Assignment 3 Question 9, Gaddis
 */

//Dollar Game
#include <iostream> 
using namespace std;

int main() 
{
    //Variables 
    float quarters, dimes, nickels, pennies, Sum;
    //First 4 variables is how much of that coin
    //does the user have 
    //Sum is the addition of the coin values and the amount
    
    cout<< "Enter the number of quarters ";
    cin>> quarters;
    cout<< "Enter the number of dimes ";
    cin>> dimes;
    cout<<"Enter the number of nickels ";
    cin>> nickels;
    cout<< "Enter the number of pennies ";
    cin>> pennies;

    //Equations 
    Sum = (quarters * .25) + (dimes *.10) + (nickels * .05) + (pennies * .01);
    
    // Users sees if they win 
    
    if (Sum == 1)
        cout<< "Congratulations the amount is correct.";
    
    else if (Sum > 1)
        cout<< "The amount entered was greater than 1 dollar.";
    
    else if (Sum < 1)
        cout<< "The amount entered was less than 1 dollar.";
            
            
    return 0;
}

