/* 
 * File:   main.cpp
 * Author: Shanilka Mapatuna
 *Created on January 12, 2018, 7:29 PM
 * Assignment 3 Question 8, Gaddis
 */

//Color Mixer
#include <iostream> 
#include <string>
using namespace std;

int main() 
{
    //Variables
    string Color1, Color2;
    
    //Dependent Variables
    string Red, Yellow, Blue;
    
    // User gives Colors
    cout << "Enter 2 of the 3 color that you want to see mixed \n"
         << "Yellow, Red, or Blue \n"
         << "Case Sensitive: Capitalize first Letter \n";
    cin >> Color1 >> Color2;
    
    //User finds out the secondary color 
    
    if (Color1 == "Red" || Color2 == "Red")
    {   if (Color1 == "Blue" || Color2 == "Blue")
            cout<< "Purple";
        else if (Color1 == "Yellow" || Color2 == "Yellow")
            cout<< "Orange";
        else if (Color1 == "Red" && Color2 == "Red")
            cout<< "Red";
        else 
            cout<<"Error! Please only Enter from the Colors Given.";        
    }
    else if (Color1 == "Blue" || Color2 == "Blue")
    {   if (Color1 == Yellow || Color2 == Yellow)
            cout<< "Green";
        else if (Color1 == "Blue" && Color2 == "Blue")
            cout<< "Blue";
        else
            cout<<"Error! Please only Enter from the Colors Given.";
    }
    else if (Color1 == "Yellow" && Color2 == "Yellow")
        cout<< "Yellow";
    else 
        cout<<"Error! Please only Enter from the Colors Given.";
    
                
                
    return 0;
}

